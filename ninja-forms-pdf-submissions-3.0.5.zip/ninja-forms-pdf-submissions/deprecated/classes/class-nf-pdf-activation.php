<?php
/**
 * Run our plugin activation process.
 *
 * @since  1.3
 */
class NF_PDF_Activation {

    /**
     * Run our activation process.
     *
     * @since  1.3
     * @return void
     */
    function __construct() {
        // update_option( 'nf_pdf_convert_notifications_complete', true);
    }

}
