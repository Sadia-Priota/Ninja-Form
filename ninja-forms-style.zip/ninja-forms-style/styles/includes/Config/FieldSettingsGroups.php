<?php

return array(

    'styles' => array(
        'id' => 'styles',
        'label' => __( 'Styles', 'ninja-forms-layout-styles' ),
        'priority' => 950
    )

);